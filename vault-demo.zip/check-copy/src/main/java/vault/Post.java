package vault;

import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class Post {

	public Post() {
		}
	static String key;
	static String user1;

	public static void main(String[] args) throws Exception {
		URL url = new URL("http://localhost:8200/v1/secret/data/mySecret");
		HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();
		httpConn.setRequestMethod("POST");

		httpConn.setRequestProperty("X-Vault-Token", "root");
		httpConn.setRequestProperty("Content-Type", "application/json");
		httpConn.setDoOutput(true);

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the name of the key");
		 key = sc.nextLine();
		System.out.println("Enter the value to the key");
		 user1 = sc.nextLine();
		OutputStreamWriter writer = new OutputStreamWriter(httpConn.getOutputStream());
		writer.write("{ \"data\": { \"" + key + "\": \"" + user1 + "\" } }");
		writer.flush();
		writer.close();
		httpConn.getOutputStream().close();

		InputStream responseStream = httpConn.getResponseCode() / 100 == 2 ? httpConn.getInputStream()
				: httpConn.getErrorStream();
		Scanner s = new Scanner(responseStream).useDelimiter("\\A");
		String response = s.hasNext() ? s.next() : "";
		System.out.println(response);
//		run();

	}

	public static String getKey() {
		return key;
	}

	public static void setKey(String key) {
		Post.key = key;
	}

	public static String getUser1() {
		return user1;
	}

	public static void setUser1(String user1) {
		Post.user1 = user1;
	}

//	public static void run() throws Exception{
//		VaultResponse response = vaultTemplate.opsForKeyValue("secret", KeyValueBackend.KV_2).get("mySecret");
//
//		Scanner sc = new Scanner(System.in);
//
//		if (response.getData().get("key") != "") {
//			System.out.println("Name of key");
//			System.out.println("-------------------------------");
//			System.out.println(response.getData().get("key"));
//
//		}
//
//		System.out.println("_______________________________");
//		System.out.println();
//		System.out.println("Value");
//		System.out.println("-------------------------------");
//		System.out.println(response.getData().get("value"));
//		System.out.println("-------------------------------");
//		System.out.println();
//	
//	}
}
