package vault;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;

public class Write {
//this is for just practice Filewriter stuff
	public static void main(String[] args) {
		
		File file = new File("B:\\Unity Health Toronto\\Eclipse Enterprise\\TextFiles\\file.txt");
		if(file.exists()) {
			file.delete();
		System.out.println("File deleted if existed at the specified address");
		}
		else			
		try {
			file.createNewFile();
			System.out.println("File created");
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		try {
			PrintWriter w = new PrintWriter(file);
			System.out.println("File written");

			w.write("Hello, WOWowowo  wowowowo!!!!!!!!!!!!!!!!!");
			w.flush();
			w.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		
		
	}

}
