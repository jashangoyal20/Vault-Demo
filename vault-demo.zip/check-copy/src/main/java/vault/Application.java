package vault;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.vault.core.VaultKeyValueOperationsSupport.KeyValueBackend;
import org.springframework.vault.core.VaultSysOperations;
import org.springframework.vault.core.VaultTemplate;
import org.springframework.vault.core.VaultTransitOperations;
import org.springframework.vault.support.VaultMount;
import org.springframework.vault.support.VaultResponse;

@SpringBootApplication
public class Application implements CommandLineRunner {

	@Autowired
	private VaultTemplate vaultTemplate;

	private String key;

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		Post post = new Post();
		post.main(args);
		VaultResponse response = vaultTemplate.opsForKeyValue("secret", KeyValueBackend.KV_2).get("mySecret");

		Scanner sc = new Scanner(System.in);

		if (response.getData().get(post.getKey()) != "") {
			System.out.println("Key was successfully added to the path @mySecret");

			System.out.println("Name of key: "+post.getKey());
			System.out.println("-------------------------------");
			System.out.println(response.getData().get(post.getKey()));

		}

		System.out.println("_______________________________");

		VaultTransitOperations transOp = vaultTemplate.opsForTransit();
		VaultSysOperations sysOperations = vaultTemplate.opsForSys();

		if (!sysOperations.getMounts().containsKey("transit/")) {
			sysOperations.mount("transit", VaultMount.create("transit"));
		}
		System.out.println("Enter name of key to be made in the transit engine:");
		key = sc.nextLine();

		transOp.createKey(key);

		Encrypt encrypt = new Encrypt();
		Decrypt decrypt = new Decrypt();

		// here encrypted value is called from the Encrypt class and this is done
		// through the Hashicorp vault
		System.out.println("-----------------------------");
		String cipherText = encrypt.getCtext(key, transOp);
		System.out.println("Encrypted value: ");
		System.out.println(cipherText);

		System.out.println("Decrypted value");
		String plainText = decrypt.getPtext(key, transOp, cipherText);
		System.out.println(plainText);
		System.out.println();

		File cfile = new File("B:\\Unity Health Toronto\\Eclipse Enterprise\\TextFiles\\cfile.txt");

		File pfile = new File("B:\\Unity Health Toronto\\Eclipse Enterprise\\TextFiles\\pfile.txt");

		if (pfile.exists()) {
			pfile.delete();
			System.out.println("Plain File deleted if existed at the specified address");
		} else
			try {
				pfile.createNewFile();
				System.out.println("New Plain File created");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		if (cfile.exists()) {
			cfile.delete();
			System.out.println("Cipher File deleted if existed at the specified address");
		} else
			try {
				pfile.createNewFile();
				System.out.println("New Cipher File created");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		try {
			PrintWriter p = new PrintWriter(pfile);
			PrintWriter c = new PrintWriter(cfile);

			p.write("Plain Text: \n" + decrypt.getPtext(key, transOp, cipherText));
			p.flush();
			p.close();
			System.out.println("Plain File written");

			c.write("Cipher Text: \n" + cipherText);
			c.flush();
			c.close();
			System.out.println("Cipher File written");

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

}
