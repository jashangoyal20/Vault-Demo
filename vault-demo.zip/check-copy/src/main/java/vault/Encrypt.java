package vault;

import java.util.Scanner;

import org.springframework.vault.core.VaultTransitOperations;

public class Encrypt {

	public String ctext;

	public Encrypt(String ctext) {
		this.ctext = ctext;
	}

	public Encrypt() {
		super();
	}

	public String getCtext(String key, VaultTransitOperations transOp) {
		System.out.println("Enter the text to be encrypted");

		Scanner sc = new Scanner(System.in);
		String text = sc.nextLine();
		this.ctext = transOp.encrypt(key, text);
		
		return ctext;
	}


}
