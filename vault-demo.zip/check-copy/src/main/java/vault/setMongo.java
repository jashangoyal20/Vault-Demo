package vault;

import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

import org.springframework.web.bind.annotation.PostMapping;

public class setMongo {
	public static void main(String[] args) throws Exception {

		// this url makes the database search engine at the mentioned url after mounts
		URL url = new URL("http://localhost:8200/v1/sys/mounts/check");
		HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();

		httpConn.setRequestMethod("POST");
		httpConn.setRequestProperty("X-Vault-Token", "root");

		httpConn.setDoOutput(true);
		OutputStreamWriter writer = new OutputStreamWriter(httpConn.getOutputStream());
		writer.write("{\"type\":\"database\"}");
		writer.flush();
		writer.close();
		httpConn.getOutputStream().close();

		InputStream responseStream = httpConn.getResponseCode() / 100 == 2 ? httpConn.getInputStream() : httpConn.getErrorStream();
		Scanner s = new Scanner(responseStream).useDelimiter("\\A");
		String response = s.hasNext() ? s.next() : "";
		System.out.println(response);
		System.out.println("********Secret Engine enabled********");
		connectDatabase();
		addRole();
		getCred();

	}

	public static void connectDatabase() throws Exception {
		URL url = new URL("http://localhost:8200/v1/check/config/justchecking");
		HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();
		httpConn.setRequestMethod("POST");

		httpConn.setRequestProperty("X-Vault-Token", "root");
		httpConn.setRequestProperty("Content-Type", "application/json");

		httpConn.setDoOutput(true);

		OutputStreamWriter writer = new OutputStreamWriter(httpConn.getOutputStream());
		writer.write("{\"plugin_name\": \"mongodb-database-plugin\",\r\n" + "   \"allowed_roles\": \"test\",\r\n"
				+ "    \"connection_url\": \"mongodb://{{username}}:{{password}}@127.0.0.1:27017/admin?tls=false\",\r\n"
				+ "    \"username\": \"reportsUser\",\r\n" + "   \"password\": \"password\"\r\n" + "}");
		writer.flush();
		writer.close();
		httpConn.getOutputStream().close();

		
		InputStream responseStream = httpConn.getResponseCode() / 100 == 2 ? httpConn.getInputStream()
				: httpConn.getErrorStream();
		Scanner s = new Scanner(responseStream).useDelimiter("\\A");
		String response = s.hasNext() ? s.next() : "";
		System.out.println("********Connection made successfully********");
		System.out.println(response);
	}

	public static void addRole() throws Exception {

		URL url = new URL("http://localhost:8200/v1/check/roles/test");
		HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();
		httpConn.setRequestMethod("POST");

		httpConn.setRequestProperty("X-Vault-Token", "root");
		httpConn.setRequestProperty("Content-Type", "application/json");

		httpConn.setDoOutput(true);

		OutputStreamWriter writer = new OutputStreamWriter(httpConn.getOutputStream());
		writer.write("{\r\n" + "    \"db_name\": \"justchecking\",\r\n" + "    \"creation_statements\": [\r\n"
				+ "    \"{ \\\"db\\\": \\\"admin\\\", \\\"roles\\\": [{ \\\"role\\\": \\\"readWrite\\\" }] }\"\r\n"
				+ "    ],\r\n" + "    \"default_ttl\": \"1h\",\r\n" + "    \"max_ttl\": \"24h\"\r\n" + "}");
		writer.flush();
		writer.close();
		httpConn.getOutputStream().close();

		InputStream responseStream = httpConn.getResponseCode() / 100 == 2 ? httpConn.getInputStream()
				: httpConn.getErrorStream();
		Scanner s = new Scanner(responseStream).useDelimiter("\\A");
		String response = s.hasNext() ? s.next() : "";
		System.out.println("********Role Added********");
		System.out.println(response);
	}

	public static void getCred() throws Exception {
		URL url = new URL("http://localhost:8200/v1/check/creds/test");
		HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();
		httpConn.setRequestMethod("GET");

		httpConn.setRequestProperty("X-Vault-Token", "root");
		httpConn.setRequestProperty("Content-Type", "application/json");

		InputStream responseStream = httpConn.getResponseCode() / 100 == 2 ? httpConn.getInputStream()
				: httpConn.getErrorStream();
		Scanner s = new Scanner(responseStream).useDelimiter("\\A");
		String response = s.hasNext() ? s.next() : "";
		System.out.println("WOW!");
		System.out.println("The Credentials are here: \n");
		System.out.println(response);
	}
}
