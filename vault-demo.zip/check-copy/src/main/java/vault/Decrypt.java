package vault;

import org.springframework.vault.VaultException;
import org.springframework.vault.core.VaultTransitOperations;

public class Decrypt {

    public String ptext;
	public String getPtext(String key, VaultTransitOperations transOp, String cipherText) {
				try {	
		ptext = transOp.decrypt(key, cipherText);
							
		
				}
				catch(VaultException e) {
					System.out.println("sorry, it is not working"); 
				}
				return ptext;
		}


}
